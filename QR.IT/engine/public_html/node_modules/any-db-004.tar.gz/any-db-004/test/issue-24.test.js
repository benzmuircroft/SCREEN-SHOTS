var fs = require('fs');
var anyDB = require('../')

var config = {
  db: '/tmp/issue-24.sqlite3.db'
}

function createDB(cb) {
  if (fs.existsSync(config.db)) fs.unlinkSync(config.db);

  anyDB.createConnection("sqlite3://" + config.db, function (err, conn) {
    if (err) return cb(err);
    db = conn;

    db.query('CREATE TABLE td (id integer primary key autoincrement, gp integer, beg text, end text)', 
    function (err) {
      if (err) return cb(err);
      db.query('CREATE TABLE tdg (gp integer, beg integer, end integer)', 
      function (err) {
        if (err) return cb(err);
        cb();
      });
    });
  });
}

createDB(function (err) {
  console.log('error?', err);
})
