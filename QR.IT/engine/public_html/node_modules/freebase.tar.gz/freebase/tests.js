var freebase=require('./index');
var async=require('async');
var slow=require('slow');
var fns=require('./helpers/helpers')
var _=require('underscore');
var options={key:"AIzaSyD5GmnQC7oW9GJIWPGsJUojspMMuPusAxI"};//please don't abuse my key
var util=require("util");
var test={}



function show(results){
     console.dir(results);
     //console.log(results.reduce(function(prev,result){return prev.concat(result.synonyms)},[]).reduce(function(prev,cur){if(prev.indexOf(cur)>=0)return prev;return prev.concat([cur]);},[]).sort().join(' ').replace(/ /g,',').replace(/_/g,' '));
     }
//freebase.list("music",options,show);

freebase.notable("music",options,show)




//testit('sentence')


function done(r){
  console.log('===========done========')
}


  function testone(v, callback){
    var all=[]
    test[v].patient(function(t){
      freebase[v](t[0], t[1], function(r){
        console.log('========'+v+'=========')
        t[2](r)
      })
    },function(){callback('done')})
  }

//apply same thing to all functions
function broadly(x, obj){
  slow.walk(Object.keys(test), doit, done)
  function doit(t){
    console.log('------'+t+'------')
    obj[t](x, function(r){
      console.log(r)
    })
  }
}

function coverage(fn, tests){
  fn=Object.keys(fn)
  tests=Object.keys(test)
  return {missing:_.difference(fn,tests),
    has:_.union(fn,tests).length,
    doesnt:_.difference(fn,tests).length,
    dangling_tests:_.difference(tests,fn)
  }
}
//console.log(coverage(freebase, test))
// broadly(null,freebase)

Object.keys(test).patient(testone, done)


  //freebase.search("franklin",options,console.log)