/*! freebase.js 
 by @spencermountain
	https://github.com/spencermountain/Freebase.js
 2013-03-21 
*/

(function( $ ) {
  $.freebase = (function() {