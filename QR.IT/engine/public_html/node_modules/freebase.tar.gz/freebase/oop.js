
var freebase=require('./index');

if (typeof module !== 'undefined' && module.exports) {
  var _ = require('underscore');
  var async = require('async');
  var fns = require('./helpers/helpers');
  var data = require('./helpers/data.js').data;
}

function topic(q){
	var data=freebase.topic(q)
	console.log(data)
  //this.data=data.property
  // return this
}
t=new topic('radiohead')
// console.log(t.data)

