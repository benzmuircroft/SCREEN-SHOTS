var test_setup = {
  api_user: '<username>',
  api_key: '<password/api_key>',
  single_to: '<your_email>',
  multi_to: ['<your_email>', '<another_email>'],
  from: '<your_email>'
}
module.exports = test_setup;

