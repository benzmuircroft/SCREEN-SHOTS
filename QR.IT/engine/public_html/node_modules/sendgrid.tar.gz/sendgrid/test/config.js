var test_setup = {
  api_user: 'benzmuircroft',//'<username>',
  api_key: 'Summers;;::7',//'<password/api_key>',
  single_to: '<your_email>',
  multi_to: ['<your_email>', '<another_email>'],
  from: '<your_email>'
}
module.exports = test_setup;

