var util = require('util'),
    xmpp = require('node-xmpp'),
    EventEmitter = require('events').EventEmitter,
    stanzaUtils = require("./stanza");

exports = module.exports = FacebookChat;


var meid;
var fbcontacts=[];
var ping;


function FacebookChat(params){
  
  EventEmitter.call(this);
  var self = this;
  meid=params.facebookId;




  this.client = new xmpp.Client({//Connect the client
    jid: '-'+ params.facebookId +'@chat.facebook.com',
    api_key: params.appId,
    secret_key: params.appSecret,
    access_token: params.accessToken
  });




  this.client.on('error',function(err){self.emit('error',err);});//
  
  this.client.on('online',function(err){console.log('e'+err);
    self.emit('online');
    var presence = new xmpp.Element('presence');self.client.send(presence);//Send Presence
    ping=setInterval(function(){self.client.send(presence);}, 1000 * 20);//And keep the connection live
  });


  FacebookChat.prototype.kill=function(){//should this be here?
    clearInterval(ping);
    fbcontacts.forEach(function(to){
      self.client.send(stanzaUtils.unavaliable('-'+meid+'@chat.facebook.com',to));
      });
    ping=setTimeout(function(){
      self.client.connection._events.close();//self.client.connection._events.end();   //maybe use
      },1);
  };//unavailable



  //On stanza from facebook
  this.client.on('stanza',function(stanza){                                     console.log('stanza: '+stanza);
    if(stanza.is('iq')){
      var iq=stanzaUtils.onIq(stanza);
      if(iq && iq.type==='jabber:iq:roster'){
        self.emit('roster',iq.friends);
        iq.friends.forEach(function(f){fbcontacts.push(f.id);});
        }
      if(iq && iq.type==='vcard'){self.emit('vcard', iq.vcard);}
      }
    else if(stanza.is('presence')){
      var presence=stanzaUtils.onPresence(stanza);
      self.emit('presence',presence);
      }
    else if(stanza.is('message')){
      var message=stanzaUtils.onMessage(stanza);
      if(message && message.body){self.emit('message',message);//normal message
        }
      if(message && message.composing){self.emit('composing',message.from);//composing message
      }}
  });



}//FacebookChat(params)end







util.inherits(FacebookChat,EventEmitter);





/**
 * Send requests to facebook
 */
FacebookChat.prototype.roster=function(){//console.log('\033[37mFacebookChat.prototype.roster\033[0m');
  this.client.send(new xmpp.Element('iq',{type:'get'}).c('query',{ xmlns:'jabber:iq:roster'}));
  };
FacebookChat.prototype.send=function(to,message){
  this.client.send(stanzaUtils.message(to,message));
  };
FacebookChat.prototype.pres=function(from,to){
  this.client.send(stanzaUtils.presence(from,to));
  };
FacebookChat.prototype.unav=function(from,to){
  this.client.send(stanzaUtils.unavaliable(from,to));
  };
FacebookChat.prototype.vcard=function(to){
  var params={type:'get'};
  if(to){params.to=to;}
  this.client.send(new xmpp.Element('iq',params).c('vCard',{xmlns:'vcard-temp'}).c('want-extval',{ xmlns:'http://www.facebook.com/xmpp/vcard/photo'}));
  };
  
  
  