var hd = new require('./include.js').HeapDiff();
console.log(JSON.stringify(hd.end(), null, "  "));
