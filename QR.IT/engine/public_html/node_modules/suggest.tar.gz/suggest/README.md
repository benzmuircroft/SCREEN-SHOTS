# Suggest

![screen](https://github.com/gaving/suggest/raw/master/site/1.png)

## Usage

    % suggest
    Suggest queries from Google.
    Usage: suggest [query]

    Options:
      -i, --interactive  Search as you type
