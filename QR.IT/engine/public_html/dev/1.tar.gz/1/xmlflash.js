var http = require("http");

var server=http.createServer(function(req,res){
  //response.writeHead(200, {"Content-Type": "text/html"});
  //response.write('<!DOCTYPE "html">');
  //response.end();
  
  //req.headers.referer=='http://scanpedia.com/ar.swf';
    console.dir(req.url);
    
    
    if(req.method==='GET'&&req.headers.referer=='http://scanpedia.com/ar.swf'&&req.url==='/crossdomain.xml'){
        /*console.log("GET");
        var body='';
        req.on('data',function(data){
            body+=data;
            console.log("Partial body: "+body);
            });
        req.on('end',function(){
            console.log("Body: " + body);
            });
        res.writeHead(200,{'Content-Type':'text/html'});
        res.end('post received');*/
        //var res_=http.request({hostname:'scanpedia.com',path:'/ar.swf',method:'POST'},function(req_,res_){});

//req.on('error',function(e){console.log('problem with request: '+e.message);});
        var body='<?xml version="1.0"?><!DOCTYPE cross-domain-policy SYSTEM "/xml/dtds/cross-domain-policy.dtd"><cross-domain-policy> <site-control permitted-cross-domain-policies="all"/><allow-access-from domain="*" to-ports="*" /></cross-domain-policy>';
        res.writeHead(200,{'Content-Length':body.length,'Content-Type':'text/x-cross-domain-policy'});
        res.write(body);
        res.end();
        
        //req = http.request({hostname:'scanpedia.com',path:'/ar.swf',method:'POST'},function(req,res){});
        //req.on('error',function(e){console.log('problem with request: '+e.message);});
        //req.write('<?xml version="1.0"?><!DOCTYPE cross-domain-policy SYSTEM "/xml/dtds/cross-domain-policy.dtd"><cross-domain-policy> <site-control permitted-cross-domain-policies="all"/><allow-access-from domain="*" to-ports="*" /></cross-domain-policy>');req.end();
        
        }
  
  
  
/*
request.on('data',function(chunk){
    console.log(chunk);
    });*/



//var req = http.request({hostname:'scanpedia.com',path:'/ar.swf',method:'POST'},function(req,res){});

//req.on('error',function(e){console.log('problem with request: '+e.message);});



// write data to request body
//req.write('<?xml version="1.0"?><!DOCTYPE cross-domain-policy SYSTEM "/xml/dtds/cross-domain-policy.dtd"><cross-domain-policy> <site-control permitted-cross-domain-policies="all"/><allow-access-from domain="*" to-ports="*" /></cross-domain-policy>');req.end();













});
 
server.listen(843);